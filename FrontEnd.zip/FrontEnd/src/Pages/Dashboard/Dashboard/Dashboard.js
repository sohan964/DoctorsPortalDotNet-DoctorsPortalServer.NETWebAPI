import React from 'react';


const Dashboard = () => {
    return (
        <div>
            
            <h2>comming soon</h2>
        </div>
    );
};

export default Dashboard;