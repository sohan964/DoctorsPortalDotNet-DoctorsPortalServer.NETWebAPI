/**
 * collect card Information
 * ----------------
 * 1. stripe install
 * 2. card loadStripe and set pk
 * 3. card element
 * 4. card form
 * 5. stripe, elements
 * 6. check card error and display error
 */