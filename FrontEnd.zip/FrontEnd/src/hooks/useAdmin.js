// import { useContext, useEffect, useState } from "react"
// import { AuthContext } from "../contexts/AuthProvider";

const useAdmin = email =>{
    // const [isAdmin, setIsAdmin] = useState(false);
    // const [isAdminLoading, setIsAdminLoading] = useState(true);
    // // const {user}= useContext(AuthContext);
    // // if(user.role === 'admin'){
    // //     setIsAdmin(true);
    // //     setIsAdminLoading(false);
    // // }

    // return [isAdmin, isAdminLoading];
}

export default useAdmin;